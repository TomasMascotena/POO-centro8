package ar.org.curso.centro8.java.entities;

public class DetallePedido {
    private Pedido pedido;
    private Producto producto;
    private int cantidad;
    private double precioUnitario; 
}
// CREATE TABLE detalle_pedido (
//     id_pedido int not null,
//     id_producto int not null,
//     cantidad int not null,
//     precio_unitario decimal(10, 2) not null,
//     primary key (id_pedido, id_producto),
//     foreign key (id_pedido) references pedidos(id_pedido),
//     foreign key (id_producto) references productos(id_producto)
// );