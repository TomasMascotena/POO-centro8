package ar.org.curso.centro8.java.entities;

import java.time.LocalDateTime;

import ar.org.curso.centro8.java.enums.Estado;
import ar.org.curso.centro8.java.enums.TipoPedido;

public class Pedido {
    private int idPedido;
    private TipoPedido tipoPedido;
    private Estado estado;
    private Boolean estaPagado = false;
    private Double montoTotal;
    private LocalDateTime fechaHoraCreacion;
    private LocalDateTime fechaHoraEntrega;
    private int numeroMesa;
    private Persona responsable; //??
}
/*CREATE TABLE pedidos (
    id_pedido int auto_increment primary key,
    tipo_pedido enum('en_mesa', 'para_llevar', 'delivery') not null,
    estado enum('en_proceso', 'entregado') not null,
    esta_pagado boolean not null default false,
    monto_total decimal(10, 2) not null,
    fecha_hora_creacion datetime not null default current_timestamp,
    fecha_hora_entrega datetime null,
    numero_mesa int null,
    id_responsable int not null,
    foreign key (id_responsable) references personas(id_persona)
); */