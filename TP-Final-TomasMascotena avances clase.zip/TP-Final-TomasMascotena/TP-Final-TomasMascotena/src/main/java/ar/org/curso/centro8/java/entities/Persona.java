package ar.org.curso.centro8.java.entities;

import ar.org.curso.centro8.java.enums.Rol;

public class Persona {
    private int idPersonas;
    private String nombre;
    private String apellido;
    private Rol rol;
}
