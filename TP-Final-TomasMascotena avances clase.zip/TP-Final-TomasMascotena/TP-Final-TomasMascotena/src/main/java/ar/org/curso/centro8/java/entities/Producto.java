package ar.org.curso.centro8.java.entities;

import java.util.Locale.Category;

import ar.org.curso.centro8.java.enums.Categoria;

public class Producto {
    private int idProducto;
    private String nombre;
    private double precio;
    private Categoria categoria;
}