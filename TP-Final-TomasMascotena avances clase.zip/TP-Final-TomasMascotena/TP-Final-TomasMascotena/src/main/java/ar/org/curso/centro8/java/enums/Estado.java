package ar.org.curso.centro8.java.enums;

public enum Estado {
    EN_PROCESO, ENTREGADO;
}
