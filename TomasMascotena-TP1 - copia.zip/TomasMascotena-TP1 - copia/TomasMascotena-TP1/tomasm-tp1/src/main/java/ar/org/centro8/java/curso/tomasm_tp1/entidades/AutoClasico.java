package ar.org.centro8.java.curso.tomasm_tp1.entidades;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
//Clase "extend": AutoClasico extiende de Vehiculo posibilitando usar sus metodos y atributos
public class AutoClasico extends Vehiculo{

    /**
     * Crea un auto clasico sin precio ni radio
     * @param marca
     * @param modelo
     * @param color
     */
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    @Override
    public void informarTipo() {
        if (this.getRadio() == null){
            System.out.println("El vehiculo es un auto clasico sin radio");
        } else {
            System.out.println("El vehiculo es un auto clasico con radio");
        }
    }

    @Override
    public void cambiarRadio(Radio radio) {
        if(radio == null){
            this.radio = null;
            System.out.println("Que bajon, ya no tenes radio.");
        }else{
            super.cambiarRadio(radio);
        }    
    }
}
