package ar.org.centro8.java.curso.tomasm_tp1.test;

import ar.org.centro8.java.curso.tomasm_tp1.entidades.AutoClasico;
import ar.org.centro8.java.curso.tomasm_tp1.entidades.AutoNuevo;
import ar.org.centro8.java.curso.tomasm_tp1.entidades.Colectivo;
import ar.org.centro8.java.curso.tomasm_tp1.entidades.Radio;

public class TestVehiculos {
    public static void main(String[] args) {
        
        Radio radio1 = new Radio("JBL", 80);
        Radio radio2 = new Radio("Sony", 200);
        Radio radio3 = new Radio("Coppel", 15);
        Radio radio4 = new Radio("Samsung", 40);
        Radio radio5 = new Radio("Panacom", 150);
        
        
        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");


        System.out.println("** Test Autos Clasicos **");
        // Se crean un auto clasico
        AutoClasico autoClasico1 = new AutoClasico("Chevrolet", "C10", "Celeste");
        
        autoClasico1.informarTipo(); //Informe de un auto clasico sin radio
        autoClasico1.agregarRadio(radio1); //Se le agrega radio al auto clasico
        autoClasico1.informarTipo(); //Informe de un auto clasico sin radio
        autoClasico1.setPrecio(5000); //Se le agrega precio al auto clasico
        System.out.println(autoClasico1);
        autoClasico1.agregarRadio(radio1);//Intentamos poner dos radios en un auto
        autoClasico1.cambiarRadio(radio2);//Se le cambia de radio al auto clasico
        

        System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");


        System.out.println("** Test Colectivos **");
        // Se crea un colectivo
        Colectivo colectivo1 = new Colectivo("Mercedes Benz", "Splinter", "Gris");

        colectivo1.informarTipo(); //Informe de un colectivo sin radio
        colectivo1.agregarRadio(radio2); //Se intenta agregar una radio ya utilizada
        colectivo1.agregarRadio(radio1); //Se le agrega radio a un colectivo
        colectivo1.informarTipo(); //Informe de un colectivo con radio
        autoClasico1.cambiarRadio(null); //Dejamos el colectivo sin radio
        System.out.println(autoClasico1);

        System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
        
        
        System.out.println("** Test Autos Nuevos **");
        //Se crea un auto nuevo
        AutoNuevo autoNuevo1 = new AutoNuevo("Ford", "Focus", "Negro", "Panacom", 150);

        autoNuevo1.informarTipo();
        autoNuevo1.agregarRadio(radio3); //Intentamos ponerle dos radios a un auto nuevo
        autoNuevo1.cambiarRadio(radio3); //Le cambiamos la radio a auto nuevo
        autoNuevo1.cambiarRadio(radio2); //Intentamos cambiar una radio que ya esta utilizada
        autoNuevo1.cambiarRadio(null); //Intentamos ponerle una radio nula a un auto nuevo

    }
}
