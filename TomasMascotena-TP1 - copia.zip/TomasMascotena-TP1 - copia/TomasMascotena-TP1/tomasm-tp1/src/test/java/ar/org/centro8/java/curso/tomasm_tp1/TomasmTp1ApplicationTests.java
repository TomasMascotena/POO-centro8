package ar.org.centro8.java.curso.tomasm_tp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TomasmTp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
