package ar.org.centro8.java.curso.tomasm_tp1.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
//Clase "extend": AutoNuevo extiende de Vehiculo posibilitando usar sus metodos y atributos
public class AutoNuevo extends Vehiculo{
    
    /**
     * Crea un auto nuevo.
     * @param modelo
     * @param marca
     * @param color
     * @param radio
     * @param precio
     */
    public AutoNuevo(String marca, String modelo, String color, String marcaRadio, int potencia) {
        super(marca, modelo, color);
        this.agregarRadio(new Radio(marcaRadio, potencia));
        this.radio.setEstaConectada(true);
    }

    @Override
    public void informarTipo() {
        System.out.println("Este vehiculo es un auto nuevo");
    }

    @Override
    public void cambiarRadio(Radio radio) {
        if(radio == null){
            System.out.println("Un auto nuevo no puede no tener radio");
        }else{
            super.cambiarRadio(radio);
        }    
    }
}
