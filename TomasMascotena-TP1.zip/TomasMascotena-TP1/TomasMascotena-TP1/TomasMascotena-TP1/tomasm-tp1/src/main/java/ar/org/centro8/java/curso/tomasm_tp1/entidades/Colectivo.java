package ar.org.centro8.java.curso.tomasm_tp1.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
//Clase "extend": Colectivo extiende de Vehiculo posibilitando usar sus metodos y atributos.
//Clase final porque no se pueden crear subproductos derivados de Colectivo.
public final class Colectivo extends Vehiculo{

    /**
     * Crea un colectivo sin radio ni precio.
     * @param marca
     * @param modelo
     * @param color
     */
    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    @Override
    public void informarTipo() {
        if (this.getRadio() == null){
        System.out.println("El vehiculo es un colectivo sin radio");
        } else {
            System.out.println("El vehiculo es un colectivo con radio");
        }
    }

    @Override
    public void cambiarRadio(Radio radio) {
        if(radio == null){
            this.radio = null;
            System.out.println("Que bajon, ya no tenes radio.");
        }else{
            super.cambiarRadio(radio);
        }    
    }
}
