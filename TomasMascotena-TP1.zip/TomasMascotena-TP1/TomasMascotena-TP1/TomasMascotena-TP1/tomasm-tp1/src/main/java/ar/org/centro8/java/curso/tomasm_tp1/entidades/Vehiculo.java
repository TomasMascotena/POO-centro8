package ar.org.centro8.java.curso.tomasm_tp1.entidades;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
//Clase abstracta utilizada porque no se crearan objetos de esta clase.
public abstract class Vehiculo {
    
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    @Setter(AccessLevel.NONE)
    public Radio radio;

    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    //Metodo abstracto, cada clase le dara un uso especifico
    public abstract void informarTipo();

    //Metodo definido ya que las clases hijas la utilizaran con el mismo objetivo
    public void agregarRadio(Radio radio) {
        if (radio.isEstaConectada()) {
            System.out.println("Esta radio ya está conectada a otro vehículo.");
        } else if (this.getRadio() == null) {
            this.radio = radio;
            radio.setEstaConectada(true);
        } else {
            System.out.println("No podes tener dos radios al mismo tiempo.");
        }
    }

    //Metodo definido ya que las clases hijas la utilizaran con el mismo objetivo
    public void cambiarRadio(Radio radio) {
        if (radio.isEstaConectada()) {
            System.out.println("Esta radio ya esta siendo utilizada en otro vehiculo");
        } else {
            if (this.getRadio() != null){
                this.getRadio().setEstaConectada(false);
            }
            this.radio = radio;
            radio.setEstaConectada(true);
            System.out.println("Cambiaste tu radio a una " + radio.getMarca() + " con " +
            radio.getPotencia() + " Watts de potencia!!");
        }
    }
}
