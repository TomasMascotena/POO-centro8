package ar.org.centro8.java.curso.tomasm_tp1;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class AutoClasico extends Vehiculo{

    /**
     * Crea un auto clasico sin precio ni radio
     * @param marca
     * @param modelo
     * @param color
     */
    public AutoClasico(String modelo, String marca, String color) {
        super(modelo, marca, color);
    }

    /**
     * Crea un auto clasico con precio y/o radio.
     * @param marca
     * @param modelo
     * @param color
     * @param precio
     * @param radio
     */
    public AutoClasico(String modelo, String marca, String color, double precio, String marcaRadio, int potencia) {
        super(modelo, marca, color);
        this.setPrecio(precio);
        this.setRadio(new Radio(marcaRadio, potencia));
    }

    @Override
    public void informarTipo() {
        if (this.getRadio() == null){
            System.out.println("El vehiculo es un auto clasico sin radio");
        } else {
            System.out.println("El vehiculo es un auto clasico con radio");
        }
    }

    public void agregarRadio(Radio radio) {
        if (radio.isEstaConectada()) {
            System.out.println("Esta radio ya está conectada a otro vehículo.");
        } else if (this.getRadio() == null) {
            this.setRadio(radio);
            radio.setEstaConectada(true);
            System.out.println("Felicidades ahora tenes una radio y es una " + radio.getMarca() + 
            " con " + radio.getPotencia() + " Watts de potencia!!");
        } else {
            System.out.println("No podes tener dos radios al mismo tiempo.");
        }
    }

    @Override
    public void cambiarRadio(Radio radio) {
        super.cambiarRadio(radio);
    }

    
    

}
