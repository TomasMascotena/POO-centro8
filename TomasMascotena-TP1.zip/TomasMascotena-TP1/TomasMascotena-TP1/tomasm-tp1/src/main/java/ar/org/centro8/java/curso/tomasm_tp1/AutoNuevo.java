package ar.org.centro8.java.curso.tomasm_tp1;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class AutoNuevo extends Vehiculo{
    
    /**
     * Crea un auto nuevo sin precio.
     * @param modelo
     * @param marca
     * @param color
     * @param radio
     */
    public AutoNuevo(String marca, String modelo, String color, String marcaRadio, int potencia) {
        super(modelo, marca, color);
        this.setRadio(new Radio(marcaRadio, potencia));
    }
    
    /**
     * Crea un auto nuevo con precio.
     * @param modelo
     * @param marca
     * @param color
     * @param radio
     * @param precio
     */
    public AutoNuevo(String marca, String modelo, String color, double precio, String marcaRadio, int potencia) {
        super(marca, modelo, color);
        this.setPrecio(precio);
        this.setRadio(new Radio(marcaRadio, potencia));
    }

    @Override
    public void informarTipo() {
        System.out.println("Este vehiculo es un auto nuevo");
    }

    @Override
    public void cambiarRadio(Radio radio) {
        super.cambiarRadio(radio);
    }
}
