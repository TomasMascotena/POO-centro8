package ar.org.centro8.java.curso.tomasm_tp1;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Radio {
    private String marca;
    private int potencia;
    private boolean estaConectada;
    
    public Radio(String marca, int potencia){
        this.marca = marca;
        this.potencia = potencia;
    }

    /**
     * Comprueba si una radio esta conectada a un vehiculo
     * @return
     */
    public boolean isEstaConectada(){
        return estaConectada;
    }

    /**
     * Cambia el estado de la conexion de un vehiculo
     * @param estaConectada
     */
    public void setEstaConectada(boolean estaConectada){
        this.estaConectada = estaConectada;
    }
    
}