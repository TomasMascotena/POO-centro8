package ar.org.centro8.java.curso.tomasm_tp1;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
//Clase abstracta porque luego se utilizan sus metodos y atributos en otras clases.
public abstract class Vehiculo {

    // cambiar flechas de diagrama
    // agregar carpetas con entidades
    // cambiar definicion de abstract a que no puede generar objetos
    // con set se puede agregar radio, arreglar
    // aclarar que significa la palabra reservada extend en cada clase
    // arreglar orden de los atributos en cada clase
    // cuando crea un auto nuevo con radio queda false el is.conectada
    // no hace falta volver a declarar los metodos abstractos en cada clase hija, puedo usarlos igual, se llama recursividad
    // agregar parametro para que no pueda poner una radio null en auto nuevo
    // agregar parametro para que pueda poner una radio null en auto clasico y colectivo en cambiarRadio y agregarRadio
    // agregar final a colectivo porque no pueden haber subproductos
    // ver si puedo poner una radio ya creada cuando instancio un objeto en vez de declarar una radio nueva cada vez


    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private Radio radio;

    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    //Metodo abstracto, cada clase le dara un uso especifico
    public abstract void informarTipo();

    //Metodo definido ya que las clases hijas la utilizaran con el mismo objetivo
    public void cambiarRadio(Radio radio) {
        if (radio.isEstaConectada()) {
            System.out.println("Esta radio ya esta siendo utilizada en otro vehiculo");
        } else {
            if (this.getRadio() != null){
                this.getRadio().setEstaConectada(false);
            }
            this.setRadio(radio);
            radio.setEstaConectada(true);
            System.out.println("Cambiaste tu radio a una " + radio.getMarca() + " con " +
            radio.getPotencia() + " Watts de potencia!!");
        }
    }

}
