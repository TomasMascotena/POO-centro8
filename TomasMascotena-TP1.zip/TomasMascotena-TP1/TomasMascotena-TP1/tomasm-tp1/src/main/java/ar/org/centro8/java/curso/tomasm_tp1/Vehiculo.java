package ar.org.centro8.java.curso.tomasm_tp1;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
//Clase abstracta porque luego se utilizan sus metodos y atributos en otras clases.
public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private Radio radio;

    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    //Metodo abstracto, cada clase le dara un uso especifico
    public abstract void informarTipo();

    //Clase definida ya que las clases hijas la utilizaran con el mismo objetivo
    public void cambiarRadio(Radio radio) {
        if (radio.isEstaConectada()) {
            System.out.println("Esta radio ya esta siendo utilizada en otro vehiculo");
        } else {
            if (this.getRadio() != null){
                this.getRadio().setEstaConectada(false);
            }
            this.setRadio(radio);
            radio.setEstaConectada(true);
            System.out.println("Cambiaste tu radio a una " + radio.getMarca() + " con " +
            radio.getPotencia() + " Watts de potencia!!");
        }
    }

}
