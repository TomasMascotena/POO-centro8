package ar.org.centro8.java.curso.tomasm_tp1;

public class TestVehiculos {
    public static void main(String[] args) {
        
        Radio radio1 = new Radio("JBL", 80);
        Radio radio2 = new Radio("Sony", 200);
        Radio radio3 = new Radio("Coppel", 15);
        Radio radio4 = new Radio("Samsung", 40);
        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");

        System.out.println("** Test Autos Clasicos **");
        //Se crean un auto sin radio ni precio y un auto al cual se le otorga un precio y radio en el momento.
        AutoClasico autoClasico1 = new AutoClasico("Chevrolet", "C10", "Celeste");
        AutoClasico autoClasico2 = new AutoClasico("Chevrolet", "Corvette", "Rojo",
                                                8000, "Panacom", 150);
        
        autoClasico1.informarTipo(); //Informe de un auto clasico sin radio
        autoClasico2.informarTipo(); //Informe de un auto clasico con radio
        autoClasico1.agregarRadio(radio1); //Se le agrega radio a un auto que no tiene
        autoClasico2.agregarRadio(radio3);  //Se intenta agregar una radio a un auto que ya tiene radio
        autoClasico2.cambiarRadio(radio2);  //Se cambia la radio de un auto
        autoClasico2.cambiarRadio(radio1);  //Se intenta utilizar una radio que ya esta en otro vehiculo
        

        System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
        System.out.println("** Test Colectivos **");
        //Se crean un colectivo sin radio ni precio y un colectivo al cual se le otorga un precio y radio en el momento.
        Colectivo colectivo1 = new Colectivo("Mercedes Benz", "Splinter", "Gris");
        Colectivo colectivo2 = new Colectivo("Renault", "Trafic", "Gris", 0, "Sonos", 90);
        
        colectivo1.informarTipo(); //Informe de un colectivo sin radio
        colectivo2.informarTipo(); //Informe de un colectivo con radio
        colectivo1.agregarRadio(radio2); //Se intenta agregar una radio ya utilizada
        colectivo1.agregarRadio(radio3); //Se le agrega radio a un colectivo
        colectivo2.agregarRadio(radio4); //Se le intenta agregar radio a un colectivo que ya tiene otra radio

        System.out.println("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n");
        System.out.println("** Test Autos Nuevos **");
        //Se crean dos autos uno sin precio y el otro con
        AutoNuevo autoNuevo1 = new AutoNuevo("Volkswagen", "Gol", "Verde", "Bose", 120);
        AutoNuevo autoNuevo2 = new AutoNuevo("Tesla", "Cybertruck", "Plateado", 80000, "LG", 500);
        autoNuevo1.informarTipo();
        autoNuevo2.informarTipo();
    }
}
